package com.example.catatanpengeluaran

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF172554)
private val Blue = Color(0xFF3563E9)
private val Green = Color(0xFF15966A)
private val Red = Color(0xFFE05252)
private val Bg = Color(0xFFF5F7FC)

data class Transaction(val id: Long, val title: String, val amount: Long,
                       val category: String, val income: Boolean, val date: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Bg)) {
                ExpenseApp(
                    load = { getSharedPreferences("ledger", MODE_PRIVATE).getString("items", "[]") ?: "[]" },
                    save = { getSharedPreferences("ledger", MODE_PRIVATE).edit().putString("items", it).apply() }
                )
            }
        }
    }
}

@Composable
fun ExpenseApp(load: () -> String, save: (String) -> Unit) {
    val transactions = remember {
        mutableStateListOf<Transaction>().apply {
            try {
                val arr = JSONArray(load())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(Transaction(o.getLong("id"), o.getString("title"), o.getLong("amount"),
                        o.getString("category"), o.getBoolean("income"), o.getString("date")))
                }
            } catch (_: Exception) {}
        }
    }
    fun persist() {
        val arr = JSONArray()
        transactions.forEach { t ->
            arr.put(JSONObject().put("id", t.id).put("title", t.title).put("amount", t.amount)
                .put("category", t.category).put("income", t.income).put("date", t.date))
        }
        save(arr.toString())
    }
    val income = transactions.filter { it.income }.sumOf { it.amount }
    val expense = transactions.filter { !it.income }.sumOf { it.amount }
    val balance = income - expense
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Bg,
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }, containerColor = Blue, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Tambah transaksi")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).background(Blue, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AccountBalanceWallet, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Dompetku", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text("Catatan keuangan pribadi", color = Color.Gray, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(22.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Navy), shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("TOTAL SALDO", color = Color(0xFFCFD8F5), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(7.dp))
                    Text(rupiah(balance), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SummaryItem("Pemasukan", income, Green, true, Modifier.weight(1f))
                        SummaryItem("Pengeluaran", expense, Color(0xFFFF8A8A), false, Modifier.weight(1f))
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Riwayat transaksi", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("${transactions.size} transaksi", fontSize = 12.sp, color = Color.Gray)
            }
            Spacer(Modifier.height(10.dp))
            if (transactions.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Belum ada transaksi", color = Navy, fontWeight = FontWeight.SemiBold)
                        Text("Tekan tombol + untuk mencatat transaksi pertama.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    items(transactions.sortedByDescending { it.id }, key = { it.id }) { item ->
                        TransactionRow(item, onDelete = { transactions.remove(item); persist() })
                    }
                }
            }
        }
    }
    if (showDialog) {
        AddTransactionDialog(onDismiss = { showDialog = false }, onSave = { title, amount, category, isIncome ->
            transactions.add(Transaction(System.currentTimeMillis(), title, amount, category, isIncome,
                SimpleDateFormat("dd MMM yyyy", Locale("id", "ID")).format(Date())))
            persist()
            showDialog = false
        })
    }
}

@Composable
fun SummaryItem(label: String, amount: Long, tint: Color, up: Boolean, modifier: Modifier = Modifier) {
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (up) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                null, tint = tint, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(4.dp))
            Text(label, color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
        }
        Spacer(Modifier.height(5.dp))
        Text(rupiah(amount), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun TransactionRow(item: Transaction, onDelete: () -> Unit) {
    Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(if (item.income) Color(0xFFE7F7F0) else Color(0xFFFFEEEE), CircleShape),
                contentAlignment = Alignment.Center) {
                Icon(if (item.income) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    null, tint = if (item.income) Green else Red)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, color = Navy, fontWeight = FontWeight.SemiBold)
                Text("${item.category} • ${item.date}", color = Color.Gray, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("${if (item.income) "+" else "-"}${rupiah(item.amount)}",
                    color = if (item.income) Green else Red, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                IconButton(onClick = onDelete, modifier = Modifier.size(25.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun AddTransactionDialog(onDismiss: () -> Unit,
                         onSave: (String, Long, String, Boolean) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Makanan") }
    var isIncome by remember { mutableStateOf(false) }
    val categories = listOf("Makanan", "Transportasi", "Belanja", "Tagihan", "Hiburan", "Gaji", "Lainnya")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah transaksi", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !isIncome, onClick = { isIncome = false }, label = { Text("Pengeluaran") })
                    FilterChip(selected = isIncome, onClick = { isIncome = true }, label = { Text("Pemasukan") })
                }
                OutlinedTextField(title, { title = it }, label = { Text("Nama transaksi") }, singleLine = true)
                OutlinedTextField(amount, { amount = it.filter(Char::isDigit) },
                    label = { Text("Nominal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true)
                Text("Kategori", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    categories.take(4).forEach { c ->
                        FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 10.sp) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    categories.drop(4).forEach { c ->
                        FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c, fontSize = 10.sp) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = amount.toLongOrNull()
                if (title.isNotBlank() && n != null && n > 0) onSave(title.trim(), n, category, isIncome)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

fun rupiah(value: Long): String = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
}.format(value)
