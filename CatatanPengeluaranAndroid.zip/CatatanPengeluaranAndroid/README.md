# Dompetku — Catatan Pengeluaran Android

Aplikasi Android native sederhana untuk mencatat pemasukan dan pengeluaran.

## Fitur
- Saldo otomatis (pemasukan dikurangi pengeluaran)
- Tambah transaksi pemasukan/pengeluaran
- Kategori transaksi
- Riwayat transaksi terbaru
- Hapus transaksi
- Data tersimpan lokal di perangkat (SharedPreferences)

## Cara mendapatkan APK tanpa memasang Android Studio

Project ini sudah memiliki workflow GitHub Actions untuk membangun APK.

1. Unduh dan ekstrak ZIP project ini.
2. Buat repository baru di GitHub, misalnya `dompetku-android`.
3. Upload seluruh isi folder project ke repository tersebut (termasuk folder `.github`).
4. Buka tab **Actions** pada repository. Jika diminta, izinkan Actions.
5. Pilih workflow **Build APK Android**, lalu tekan **Run workflow**.
6. Tunggu proses selesai. Buka hasil workflow yang berstatus sukses.
7. Di bagian **Artifacts**, unduh `Dompetku-debug-apk` dan ekstrak ZIP-nya.
8. File `app-debug.apk` adalah APK yang dipasang di HP Android.

## Build lokal
Buka folder ini di Android Studio versi terbaru, tunggu Gradle sync, lalu pilih **Build > Build APK(s)**.

## Catatan
- APK debug cocok untuk pemasangan pribadi dan pengujian, bukan rilis Play Store.
- Data transaksi disimpan di perangkat ini. Menghapus data aplikasi dapat menghapus catatan transaksi.
- APK belum ditandatangani sebagai rilis Play Store.
